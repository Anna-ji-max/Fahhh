package com.instafocus;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * InstaFocus v5 service.
 *
 * Performance architecture:
 *  - Three overlay views are created once and kept attached while Instagram is active.
 *  - Mode changes only toggle visibility/update LayoutParams; views are never removed and re-added.
 *  - No 160/350ms polling loop. Instagram accessibility events drive refreshes.
 *  - Bottom navigation clicks are classified directly from the event, avoiding a full tree walk.
 *  - A small delayed tree scan is used only when necessary (launch/back/content changes/search text).
 */
public class InstaAccessibilityService extends AccessibilityService {
    private static final String INSTAGRAM = "com.instagram.android";
    private static final long REFRESH_TOKEN = 0x49534635L;
    private static final long SEARCH_TOKEN = 0x49534636L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private android.content.SharedPreferences prefs;
    private WindowManager wm;

    private BlockView homeFeed;
    private BlockView reelsFull;
    private BlockView searchBlock;
    private BlockView reelsNavBlock;
    private boolean overlaysAttached;
    private boolean instagramForeground;

    private Mode mode = Mode.NONE;
    private boolean searchHasQuery;
    private int lastWidth;
    private int lastHeight;

    private enum Mode { NONE, HOME, REELS, SEARCH, MESSAGES, OTHER }

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.flags |= AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
            setServiceInfo(info);
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        instagramForeground = root != null && INSTAGRAM.equals(String.valueOf(root.getPackageName()));
        if (instagramForeground) {
            mode = Mode.HOME;
            ensureOverlays();
            applyLayout(false);
            scheduleTreeRefresh(25);
        }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        String pkg = event.getPackageName() == null ? "" : event.getPackageName().toString();

        // Never react to our own accessibility events.
        if (getPackageName().equals(pkg)) return;

        if (!INSTAGRAM.equals(pkg)) {
            if (instagramForeground) {
                instagramForeground = false;
                mode = Mode.NONE;
                searchHasQuery = false;
                hideAll();
            }
            return;
        }

        if (!instagramForeground) {
            instagramForeground = true;
            if (mode == Mode.NONE || mode == Mode.OTHER) mode = Mode.HOME;
            ensureOverlays();
            applyLayout(false);
        }

        // Fast path: Instagram bottom navigation and major buttons expose their label
        // directly in click events. Switch the persistent overlay on the same UI turn.
        if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            Mode clicked = modeFromEvent(event);
            if (clicked != Mode.NONE) {
                mode = clicked;
                if (mode != Mode.SEARCH) searchHasQuery = false;
                applyLayout(false);
                if (mode == Mode.SEARCH) scheduleSearchRefresh(20);
                return;
            }
        }

        // Window changes and content changes need a lightweight tree refresh. There is
        // intentionally no long debounce/polling loop: the next frame is enough.
        int type = event.getEventType();
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            type == AccessibilityEvent.TYPE_VIEW_SCROLLED ||
            type == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            scheduleTreeRefresh(type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ? 0 : 16);
        }
    }

    private Mode modeFromEvent(AccessibilityEvent e) {
        StringBuilder b = new StringBuilder();
        if (e.getText() != null) for (CharSequence x : e.getText()) b.append(' ').append(x);
        if (e.getContentDescription() != null) b.append(' ').append(e.getContentDescription());
        String t = b.toString().toLowerCase(Locale.ROOT).trim();
        if (t.contains("reels")) return Mode.REELS;
        if (t.contains("search") || t.contains("explore")) return Mode.SEARCH;
        if (t.contains("message") || t.contains("inbox")) return Mode.MESSAGES;
        if (t.equals("home") || t.contains("home tab") || t.contains("home, selected")) return Mode.HOME;
        return Mode.NONE;
    }

    private void scheduleTreeRefresh(long delay) {
        handler.removeCallbacksAndMessages(REFRESH_TOKEN);
        handler.postAtTime(() -> refreshFromTree(), REFRESH_TOKEN,
                SystemClock.uptimeMillis() + Math.max(0, delay));
    }

    private void scheduleSearchRefresh(long delay) {
        handler.removeCallbacksAndMessages(SEARCH_TOKEN);
        handler.postAtTime(() -> refreshSearchQuery(), SEARCH_TOKEN,
                SystemClock.uptimeMillis() + Math.max(0, delay));
    }

    private void refreshFromTree() {
        if (!instagramForeground) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || !INSTAGRAM.equals(String.valueOf(root.getPackageName()))) return;

        State state = classify(root);
        if (state.mode != Mode.NONE && state.mode != Mode.OTHER) {
            mode = state.mode;
        }
        if (mode == Mode.SEARCH) searchHasQuery = state.query;
        else searchHasQuery = false;

        ensureOverlays();
        applyLayout(false);
    }

    private void refreshSearchQuery() {
        if (!instagramForeground || mode != Mode.SEARCH) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        boolean query = containsTypedSearch(root);
        if (query != searchHasQuery) {
            searchHasQuery = query;
            applyLayout(false);
        }
    }

    private static final class State {
        final Mode mode; final boolean query;
        State(Mode m, boolean q) { mode=m; query=q; }
    }

    private State classify(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> nodes = new ArrayList<>();
        collect(root, nodes, 0);

        boolean selectedReels=false, selectedSearch=false, selectedHome=false;
        boolean reelsHeader=false, searchHeader=false, story=false, query=false;

        for (AccessibilityNodeInfo n : nodes) {
            String raw = n.getText()==null ? "" : n.getText().toString().trim();
            String cd = n.getContentDescription()==null ? "" : n.getContentDescription().toString().trim();
            String t = (raw + " " + cd).toLowerCase(Locale.ROOT);
            if (n.isSelected() && t.contains("reels")) selectedReels=true;
            if (n.isSelected() && (t.equals("search") || t.contains("search tab") || t.contains("search and explore"))) selectedSearch=true;
            if (n.isSelected() && (t.equals("home") || t.contains("home tab") || t.contains("home, selected"))) selectedHome=true;
            if (t.equals("reels") || t.contains("reels tab") || t.contains("reels, selected")) reelsHeader=true;
            if (t.contains("search with meta ai") || t.contains("search instagram") || t.contains("search and explore")) searchHeader=true;
            if (t.equals("your story") || t.contains("create story") || t.contains("add to story")) story=true;
            if (n.isEditable() && !raw.isEmpty()) query=true;
        }

        // Strong navigation signals first. This prevents Home's ordinary post labels
        // (likes/comments/share) from being mistaken for the Reels screen.
        if (selectedReels) return new State(Mode.REELS, false);
        if (selectedSearch) return new State(Mode.SEARCH, query);
        if (selectedHome) return new State(Mode.HOME, false);

        // Content signatures are only fallbacks when selected-state isn't exposed.
        if (reelsHeader && hasReelsVerticalActions(nodes)) return new State(Mode.REELS, false);
        if (searchHeader && hasSearchGrid(nodes)) return new State(Mode.SEARCH, query);
        if (story) return new State(Mode.HOME, false);

        // Never downgrade a known mode because Instagram emitted a partial tree during
        // an animation. This is the key anti-flicker rule.
        return new State(mode, mode == Mode.SEARCH && query);
    }

    private boolean hasReelsVerticalActions(List<AccessibilityNodeInfo> nodes) {
        int count=0;
        for (AccessibilityNodeInfo n : nodes) {
            String t=text(n);
            if (t.contains("like") || t.contains("comment") || t.contains("share") || t.contains("audio") || t.contains("remix")) count++;
        }
        return count >= 2;
    }

    private boolean hasSearchGrid(List<AccessibilityNodeInfo> nodes) {
        int imageLike=0;
        for (AccessibilityNodeInfo n : nodes) {
            CharSequence cd=n.getContentDescription();
            if (cd != null && cd.length()>0) imageLike++;
            if (n.getClassName()!=null && n.getClassName().toString().contains("ImageView")) imageLike++;
        }
        return imageLike >= 6;
    }

    private boolean containsTypedSearch(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> nodes=new ArrayList<>();
        collect(root,nodes,0);
        for (AccessibilityNodeInfo n:nodes) {
            if (n.isEditable()) {
                String t=n.getText()==null?"":n.getText().toString().trim();
                if (!t.isEmpty()) return true;
            }
        }
        return false;
    }

    private String text(AccessibilityNodeInfo n) {
        String a=n.getText()==null?"":n.getText().toString();
        String b=n.getContentDescription()==null?"":n.getContentDescription().toString();
        return (a+" "+b).toLowerCase(Locale.ROOT);
    }

    private void collect(AccessibilityNodeInfo node,List<AccessibilityNodeInfo> out,int depth) {
        if (node==null || depth>14 || out.size()>350) return;
        out.add(node);
        for(int i=0;i<node.getChildCount();i++) {
            AccessibilityNodeInfo c=node.getChild(i);
            if(c!=null) collect(c,out,depth+1);
        }
    }

    private void ensureOverlays() {
        if (overlaysAttached || wm == null) return;
        homeFeed = new BlockView(this, false);
        reelsNavBlock = new BlockView(this, false);
        reelsFull = new BlockView(this, false);
        searchBlock = new BlockView(this, true);

        addPersistent(homeFeed, "home-feed");
        addPersistent(reelsNavBlock, "reels-nav");
        addPersistent(reelsFull, "reels-full");
        addPersistent(searchBlock, "search-suggestions");
        overlaysAttached = true;
        lastWidth = 0; lastHeight = 0;
    }

    private void addPersistent(BlockView v, String title) {
        int w=getResources().getDisplayMetrics().widthPixels;
        int h=getResources().getDisplayMetrics().heightPixels;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(
                Math.max(1,w), Math.max(1,h),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.OPAQUE);
        p.gravity=Gravity.TOP|Gravity.START;
        p.x=0; p.y=0;
        p.setTitle("InstaFocus:"+title);
        try { wm.addView(v,p); } catch(Exception ignored) { }
    }

    private void applyLayout(boolean force) {
        if (!overlaysAttached) return;
        int w=getResources().getDisplayMetrics().widthPixels;
        int h=getResources().getDisplayMetrics().heightPixels;
        if (!force && w==lastWidth && h==lastHeight && homeFeed.getVisibility()==desiredVisibility(homeFeed)) {
            // Visibility can still change with mode, so continue below; this condition only
            // avoids needless size work when nothing changed.
        }
        lastWidth=w; lastHeight=h;

        hideAll();
        if (!instagramForeground) return;
        if (prefs == null) prefs=getSharedPreferences("settings",MODE_PRIVATE);

        switch(mode) {
            case HOME:
                if (prefs.getBoolean("home",true)) {
                    setRect(homeFeed,0,findHomeFeedTop(h),w,Math.max(0,h-systemBarBottom()),true);
                    setRect(reelsNavBlock,(int)(w*.60f),Math.max(0,h-systemBarBottom()-4), (int)(w*.80f),h,false);
                }
                break;
            case REELS:
                if (prefs.getBoolean("reels",true)) setRect(reelsFull,0,0,w,Math.max(1,h-systemBarBottom()),true);
                break;
            case SEARCH:
                if (prefs.getBoolean("search",true) && !searchHasQuery) {
                    setRect(searchBlock,0,(int)(h*.155f),w,(int)(h*.58f),true);
                }
                break;
            default: break;
        }
    }

    private int desiredVisibility(View v) { return v.getVisibility(); }

    private int systemBarBottom() { return Math.max(72, (int)(getResources().getDisplayMetrics().heightPixels*.055f)); }

    private int findHomeFeedTop(int h) {
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root!=null) {
            List<AccessibilityNodeInfo> nodes=new ArrayList<>(); collect(root,nodes,0);
            int maxStoryBottom=0;
            for(AccessibilityNodeInfo n:nodes) {
                String t=text(n);
                if(t.contains("your story") || t.contains("create story") || t.contains("add to story")) {
                    android.graphics.Rect r=new android.graphics.Rect(); n.getBoundsInScreen(r);
                    maxStoryBottom=Math.max(maxStoryBottom,r.bottom);
                }
            }
            if(maxStoryBottom>0) return Math.min((int)(h*.40f), maxStoryBottom+dp(30));
        }
        return (int)(h*.235f);
    }

    private int dp(int v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    private void setRect(View v,int left,int top,int right,int bottom,boolean visible) {
        if(v==null) return;
        WindowManager.LayoutParams p=(WindowManager.LayoutParams)v.getLayoutParams();
        if(p==null) return;
        p.width=Math.max(1,right-left); p.height=Math.max(1,bottom-top); p.x=left; p.y=top;
        try { wm.updateViewLayout(v,p); } catch(Exception ignored) { }
        v.setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    private void hideAll() {
        if(homeFeed!=null) homeFeed.setVisibility(View.GONE);
        if(reelsNavBlock!=null) reelsNavBlock.setVisibility(View.GONE);
        if(reelsFull!=null) reelsFull.setVisibility(View.GONE);
        if(searchBlock!=null) searchBlock.setVisibility(View.GONE);
    }

    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(REFRESH_TOKEN);
        handler.removeCallbacksAndMessages(SEARCH_TOKEN);
        if(wm!=null) {
            if(homeFeed!=null) safeRemove(homeFeed);
            if(reelsNavBlock!=null) safeRemove(reelsNavBlock);
            if(reelsFull!=null) safeRemove(reelsFull);
            if(searchBlock!=null) safeRemove(searchBlock);
        }
        overlaysAttached=false;
        super.onDestroy();
    }

    private void safeRemove(View v) { try { wm.removeViewImmediate(v); } catch(Exception ignored) {} }

    private class BlockView extends View {
        private final boolean drawQuote;
        private float downX,downY;
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        BlockView(android.content.Context c,boolean q) {
            super(c); drawQuote=q; setClickable(true); setFocusable(false);
            setLayerType(View.LAYER_TYPE_HARDWARE,null);
            setBackgroundColor(surfaceColor());
            setOnTouchListener((v,e)-> { handleTouch(e); return true; });
        }
        private int surfaceColor() {
            boolean dark=(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
            return dark ? Color.rgb(8,11,15) : Color.rgb(250,250,250);
        }
        private void handleTouch(MotionEvent e) {
            if(mode==Mode.REELS) {
                if(e.getActionMasked()==MotionEvent.ACTION_DOWN){downX=e.getRawX();downY=e.getRawY();}
                else if(e.getActionMasked()==MotionEvent.ACTION_UP){
                    float dx=e.getRawX()-downX, dy=Math.abs(e.getRawY()-downY);
                    if(downX<dp(48) && dx>dp(90) && dy<dp(120)) performGlobalAction(GLOBAL_ACTION_BACK);
                }
            }
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if(!drawQuote) return;
            boolean dark=(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(android.graphics.Typeface.create("sans",android.graphics.Typeface.NORMAL));
            paint.setColor(dark?Color.WHITE:Color.rgb(25,25,28));
            float cx=getWidth()/2f;
            paint.setTextSize(Math.max(25f,Math.min(40f,getWidth()*.052f)));
            canvas.drawText("Protect your attention.",cx,getHeight()*.43f,paint);
            paint.setTextSize(Math.max(18f,Math.min(27f,getWidth()*.036f)));
            canvas.drawText("Search with purpose, then leave.",cx,getHeight()*.58f,paint);
            paint.setColor(Color.rgb(131,58,180));
            paint.setTextSize(Math.max(17f,Math.min(25f,getWidth()*.033f)));
            canvas.drawText("InstaFocus",cx,getHeight()*.75f,paint);
        }
    }
}
