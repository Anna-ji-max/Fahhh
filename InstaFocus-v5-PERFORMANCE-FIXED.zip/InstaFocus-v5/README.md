# InstaFocus v5

This version focuses on reliable blocking behavior:
- Opaque Instagram-like blocking surfaces (dark/light adaptive).
- Reels mode is retained during incomplete accessibility snapshots, preventing the blocker from disappearing during swipes/loading.
- Home blocks the feed while leaving the Story row visible.
- Reels bottom-nav blocker is positioned over the fourth tab.
- Search leaves the search field available while covering the suggestion area with an opaque surface.
- Overlay views are not recreated unless their required state changes, avoiding blinking.

Build with GitHub Actions using JDK 17 and Android Gradle Plugin 8.6.1.


Performance architecture: persistent accessibility overlay views, event-driven mode switching, no periodic 350ms polling, and no remove/re-add cycle during normal navigation.
